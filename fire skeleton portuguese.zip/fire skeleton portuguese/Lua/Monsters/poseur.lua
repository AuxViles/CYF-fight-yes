-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"Como está flutuando assim.", "Cheira a cinzas.", "Está ficando quente."}
commands = {"Piada", "Insulto", "Elogio"}
randomdialogue = {"Gostoso e \ngostoso", "Tão quente...", "Você está frio"}

autolinebreak = true

sprite = "poseur" --Always PNG. Extension is added automatically.
name = "Esqueleto de fogo"
gold = 30
xp = 10
hp = 100
atk = 5
def = 2
check = "Uma cabeça flutuante que está pegando fogo ... uau."
dialogbubble = "right" -- See documentation for what bubbles you have available.
canspare = false
cancheck = true

-- Happens after the slash animation but before 
function HandleAttack(attackstatus)
    if attackstatus == -1 then
        -- player pressed fight but didn't press Z afterwards
    else
        -- player did actually attack
    end
end
 
-- This handles the commands; all-caps versions of the commands list you have above.
function HandleCustomCommand(command)
    if command == "PIADA" then
        currentdialogue = {"Haha."}
        canspare = true
    elseif command == "INSULTO" then
        currentdialogue = {"grrr."}
    elseif command == "ELGIO" then
        currentdialogue = {"Obrigado"}
    end
    BattleDialog({"Você selecionou " .. command .. "."})
end