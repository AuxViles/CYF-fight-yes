-- A basic encounter script skeleton you can copy and modify for your own creations.

-- music = "shine_on_you_crazy_diamond" --Either OGG or WAV. Extension is added automatically. Uncomment for custom music.
encountertext = "Esqueleto de fogo sai do \nfogo!" --Modify as necessary. It will only be read out in the action select screen.
nextwaves = {"bullettest_chaserorb"}
wavetimer = 4.0
arenasize = {155, 130}

enemies = {
"poseur"
}

enemypositions = {
{0, 80}
}

-- A custom list with attacks to choose from. Actual selection happens in EnemyDialogueEnding(). Put here in case you want to use it.
possible_attacks = {"bullettest_bouncy", "bullettest_chaserorb", "bullettest_touhou"}

function EncounterStarting()
    -- If you want to change the game state immediately, this is the place.
    Inventory.AddCustomItems({"hamburger","rosquinha", "rosquinha","copo de água"},{0,0,0,1})
    Inventory.SetInventory({"hamburger", "rosquinha", "rosquinha","copo de água"})
end

function EnemyDialogueStarting()
    -- Good location for setting monster dialogue depending on how the battle is going.
end

function EnemyDialogueEnding()
    -- Good location to fill the 'nextwaves' table with the attacks you want to have simultaneously.
    nextwaves = { possible_attacks[math.random(#possible_attacks)] }
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
end

function HandleSpare()
    State("ENEMYDIALOGUE")
end

function HandleItem(ItemID)
    if ItemID == "ROSQUINHA" then
        Player.Heal(30)
        BattleDialog({"Não é bom para você mas gostoso"})
    end
    if ItemID == "HAMBURGER" then
        Player.Heal(1000)
        BattleDialog({"Não é saudável, mas saboroso"})
    end
    if ItemID == "COPO DE ÁGUA" then
        Inventory.SetAmount(999999)
        BattleDialog({"Água..."})
    end
    BattleDialog({"Item selecionado " .. ItemID .. "."})
end