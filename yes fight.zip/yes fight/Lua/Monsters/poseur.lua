-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"keep fighting.", "keep fighting", "[color:ff0000]KEEP FIGHTING..."}
commands = {"Lower Defense", "Lower Attack", "Hypnotise"}
randomdialogue = {"...", "...", "..."}

sprite = "AuxViles" --Always PNG. Extension is added automatically.
name = "Aux"
hp = 1000
atk = 50
def = 60
xp = 304538
gold = 6548679769
check = "His attacks penatrate armor so defense is useless."
dialogbubble = "right" -- See documentation for what bubbles you have available.
canspare = false
cancheck = true

-- Happens after the slash animation but before 
function HandleAttack(attackstatus)
    if attackstatus == -1 then
        -- player pressed fight but didn't press Z afterwards
    else
        -- player did actually attack
    end
end
 
-- This handles the commands; all-caps versions of the commands list you have above.
function HandleCustomCommand(command)
    if command == "Lower Defense" then
        currentdialogue = {"uh oh"}
        def = def - 10
        wait("200")
        def = def + 10
    elseif command == "Lower Attack" then
        atk = atk - 10
        wait(200)
        atk = atk + 10
        currentdialogue = {"AAAAAAAAAAAAA"}
    elseif command == "Hypnotise" then
        currentdialogue = {"h."}
        canspare = true
    end
    BattleDialog({"You selected " .. command .. "."})
end

