-- The chasing attack from the documentation example.
chasingbullet = CreateProjectile('bullet', Arena.width/2, Arena.height/2)
chasingbullet.SetVar('xspeed', 0)
chasingbullet.SetVar('yspeed', 0)

sprite = "moon"

function Update()
    local xdifference = Player.x - chasingbullet.x
    local ydifference = Player.y - chasingbullet.y
    local xspeed = chasingbullet.GetVar('xspeed') / 1 + xdifference / 100
    local yspeed = chasingbullet.GetVar('yspeed') / 1 + ydifference / 100
    chasingbullet.Move(xspeed, yspeed)
    chasingbullet.SetVar('xspeed', xspeed)
    chasingbullet.SetVar('yspeed', yspeed)
end
function OnHit(bullet)
    Player.hurt(10)
end