-- Tutorial Lua
-- Unitale 2.0a Wave Attack
-- Created by batchloo1

-- Stuff I'll go over...

-- 1 ) Creating and using a spawntimer.
-- 2 ) Creating a bullet that will spawn other bullets.
-- 3 ) Insert variables into a variable.
-- 4 ) Create a table and how to use it.
-- 5 ) Create and use your very own function!
-- 6 ) How to use some shortcuts.
-- 7 ) Using the Update() function.
-- 8 ) Using if and then statements.
-- 9 ) Discuss why we use == sometimes, and = other times.
-- 10 ) And much, much more.

-- Tutorial. Start.

-- So what's going to happen in this wave?
-- First, we're going to create a spawnerbullet.
-- This spawnerbullet will create bullets of it's own.
-- The spawnerbullet will have 5 preset locations where it can spawn.
-- These bullets will spawn around the spawnerbullet.
-- These bullets will try to kill the player.

-- First, set the global variables that you will need.
-- Let's create a spawntimer, it doesn't matter what you name it. 

spawntimer = 0

-- This is a variable that can be used within your script, as long as it doesn't affect a local variable.
-- We'll most likely use this to move our spawnerbullet to set locations in the fight.

-- Now we need a way to identify where the spawnerbullet will be at a given time.
-- We'll use a global variable such as times.

times = 0

-- We'll use this later on.

-- Now we'll need to decide on a velocity that these bullets will fly at.

-- Unitale runs at 60 fps. If we set the bullets velocity at more than 3, then they will fly across the screen within a second.
-- I'll suggest a velocity of -3 now.
-- The reason it's at -3 is because it has to move down. The bullets spawn on top of the arena.
-- We'll store this in a variable called vel ( short for velocity )
-- You can use any name for this variable, but I prefer to use vel.

vel = -3

-- And now to create the actual bullet

-- Let's create the bullet that will spawn the actual bullets.
-- For this example, I used the bullet provided by the encounter skeleton, 'bullet'.

spawnerbullet = CreateProjectile('bullet', 0, Arena.height/2 + 40)

-- So I've created a variable named 'spawnerbullet'.
-- In a bit, we'll store variables inside this global variable so we can use them later on in the script.
-- I used the function...   CreateProjectile(image, x, y)
-- I used 'bullet' for the image, which you can change to anything. I suggest keeping it to 'bullet' for this tutorial.
-- The x position is set to 0, and its y position to 40 px above the arena.
-- By using Arena.height/2, I told the engine to divide the Arena height by two. This puts it at the top of the arena. You can do -Arena.height/2 to put it at the exact bottom of the arena.

-- Now we'll store variables into the variable spawnerbullet. 
-- We'll be using spawnerbullet.SetVar('varName', input)
-- 'varName' has to be surrounded by single quotes, or you're going to have a bad time.
-- input can be a number, variable name, string, a table, and many more.
-- First, we need to set the current x and y positions into the variable.

spawnerbullet.SetVar('xpos', spawnerbullet.x)

-- This sets the spawnerbullet's current x position into the variable 'xpos'.
-- If you did this correctly, then congratulations! You have inserted the spawnerbullet's x position into a variable.

-- Also, bullet.x is the x position of the bullet, while bullet.y is the y position of the bullet.
-- But how do we insert a variable into a variable?
-- First, we need to create a variable.

spawnerbulletypos = spawnerbullet.y

-- We have created a variable called spawnerbulletypos, and it currently stores the spawnerbullet's current y position.

-- Now we need to input this into the spawnerbullet variable.

spawnerbullet.SetVar('ypos', spawnerbulletypos)

-- And that's that. We used .SetVar to create a variable, called 'ypos', in spawnerbullet. It referred to the variable spawnerbulletypos and put it into the 'ypos' variable.

-- You can also just do spawnerbullet.SetVar('ypos', bullet.y)

-- A side note, you can also do math inside the input section, but I don't recommend it.
-- An example being spawnerbullet.SetVar('exampleVar', 5 + 10).

-- Now we'll be making a table which will store the bullets that spawnerbullet will create.
-- A table is a variable that houses multiple variables which can all be referred to at once.
-- For now, we'll just be creating the table.

bullets = {}

-- And that's it. Simple, isn't it? Using the curly brackets  {}  creates a table in most cases.
-- What we have done is create a variable named bullets, and then made it a table variable.
-- Tables will be your best friend in Unitale. They can perform a list of actions on all the things within the table.

-- For now, I think that we have all the variables that we need for now.

-- Let me show you how to create a function.
-- This function will be used to create the bullets that will fly at the player.

function createBullets()

-- And that's how you create a function. 
-- For now, we'll need to refer to those variables that we put in the spawnerbullet.

-- Here's a shortcut so we don't have to keep referring to that long name.

local bullet = spawnerbullet

-- We just created a local variable named bullet.
-- A local variable is a variable that can only be called within a certain action.
-- So for this example, we can only use this variable, bullet, within the function createBullets().

-- Now why did we set the local variable bullet equal to the global variable spawnerbullet?

-- 1 ) Easier to recall

-- That's pretty much it. You'll understand later on.
-- It still retains the variables that are put inside spawnerbullet, so no worries.

-- Don't worry if you don't understand, I still don't either.

-- Now we need to call upon the bullet's x position and y position.

-- They're going to be in different variables, you'll understand later.

-- We'll store them inside local variables for now.

local xpos = bullet.GetVar('newxpos')
local ypos = bullet.GetVar('newypos')

-- There, we just called upon spawnerbullet's ( called bullet for now ) variables that we stored inside it.
-- We use bullet.GetVar('varName') to call up these variables.

-- Now to create the bullets that will fly at the player!
-- This will require some set up, but I think you can do just fine.

-- Now to create the x positions and y positions for the bullets.
-- This is going to be a lot of variables, so get ready.

local xpos1 = xpos
local ypos1 = ypos - 10

local xpos2 = xpos + 10
local ypos2 = ypos

local xpos3 = xpos - 10
local ypos3 = ypos

local xpos4 = xpos + 20
local ypos4 = ypos + 10

local xpos5 = xpos - 20
local ypos5 = ypos + 10

-- I'll give you a short summary of what just happened.
-- These 5 sets of xpos and ypos will be the spawning locations for the bullets that will be spawned by the spawnerbullet.
-- These bullets will spawn in a small U formation.

-- Now we need to move the spawnerbullet to the 'xpos' and 'ypos' that was given to us earlier.
-- We'll use a special command called .MoveTo(x, y).

bullet.MoveTo(xpos, ypos)

-- If we hadn't made the local variable, bullet, refer to spawnerbullet, then we would have to use a different name for it.
-- It would have been...   spawnerbullet.MoveTo(x, y)

-- And that's all for the set up. Short, wasn't it?

-- Now we're going to create the bullets that will fly at the player.
-- We'll be doing what we did for the spawnerbullet, but with a few additions.

-- We'll be using the xpos(es) and ypos(es) we made earlier within these 5 bullets we'll be creating.
-- They will all use the 'bullet' image

-- Welp, here goes nothing.

local bullet1 = CreateProjectile('bullet', xpos1, ypos1)

local bullet2 = CreateProjectile('bullet', xpos2, ypos2)

local bullet3 = CreateProjectile('bullet', xpos3, ypos3)

local bullet4 = CreateProjectile('bullet', xpos4, ypos4)

local bullet5 = CreateProjectile('bullet', xpos5, ypos5)

-- And there we go. We've created five bullets that will be at their specific x and y positions.

-- We should put the current spawnerbullet x and y positions into these bullets
-- The y position is always the same, so let's worry about the x position.

bullet1.SetVar('origxpos', xpos)

-- Now let's do this to the rest of the bullets.

bullet2.SetVar('origxpos', xpos)
bullet3.SetVar('origxpos', xpos)
bullet4.SetVar('origxpos', xpos)
bullet5.SetVar('origxpos', xpos)

-- We'll just insert them into that fancy bullets table we made earlier.
-- There's a special command to insert these variables into the table.

table.insert(bullets, bullet1)

-- That's the command. The first part, (bullets, ...), refers to the table named bullets. The second part, (..., bullet1), refers to the bullet that we just made.
-- Let's do this for the rest of the bullets.

table.insert(bullets, bullet2)
table.insert(bullets, bullet3)
table.insert(bullets, bullet4)
table.insert(bullets, bullet5)

-- And we're done with this function.
-- Let's end it.
-- Make sure that there is an end at the end of the function, like so.

end

-- Is there an end above this? Good! Now let's actually make the script work.

-- We're going to refer to a function that had already been created for us.
-- It is the Update() function

function Update()

-- This is the function that will update this battle every frame. That's 60 updates per one second.
-- Remember the first global variable that we made? It was spawntimer.
-- We'll use it now.

spawntimer = spawntimer + 1

-- There's an easier way to do what I just did above, but I prefer doing that.
-- When referring to a global variable, you don't need "global" infront of it. All you need is the name of the variable and you are ready to go.
-- Anyway, this will set the spawntimer to add one to itself every frame. That's 60 per second.

-- We'll put this to good use!

-- We're going to use our first function. 
-- First, we need to set it so that the spawner bullet changes position every time it creates bullets.

-- Let's create the local spawnerbulletxpos variable and local spawnerbulletypos variable.

local spawnerbulletxpos = spawnerbullet.GetVar('xpos')
local spawnerbulletypos = spawnerbullet.GetVar('ypos')

-- If you don't remember why you do this, refer to earlier.

-- We're going to be using that global variable times, and a couple of if and then statements.

-- First we need to make a timer...
-- Don't worry about the double equal sign, I will explain it in a bit.

if spawntimer >= 60 then 

-- Now we're going to create the times if and then statement.

if times == 0 then

-- And we have created the if and then statement.
-- You may be wondering if I made a typo while writing that, right?
-- Wrong.

-- When doing an if and then statement, or simple checking a variable, it must have two equal signs.
-- Here's how I understand it.

-- If there were only one equal sign, it would complicate things.
-- Try finding a less than or equal to operator on your keyboard.
-- Most of you probably couldn't find one, the rest probably know what to actually do.
-- You need to do <= to get less than or equal to.
-- That's why there are two equal signs. It's so that you can also do less than or equal to, and greater than or equal to.
-- If you just want to do less than, then do <. Same goes for >.

-- If you don't understand that, then just remember two equal signs when doing if and then statements.

-- Now we'll refer to the spawnerbullet in this.
-- We've already put their xpos and ypos into local variables earlier, so we don't need to do them now.

-- For these next few if and then statements (there will be 5), we shall insert two new variables into spawnerbullet.
-- These variables are, as you guessed, 'newxpos' and 'newypos'
-- These will move the bullet to a new x position and y position in the function createBullets()

local newxpos = spawnerbulletxpos
local newypos = spawnerbulletypos

-- This may seem redundant, however we'll change these in later if and then statements.
-- Now we'll put them into the spawnerbullet variable itself.

spawnerbullet.SetVar('newxpos', newxpos)
spawnerbullet.SetVar('newypos', newypos)

-- This shouldn't need explanation.

-- Guess what... We'll be using your function!
-- Just do this.

createBullets()

-- This refers to your function from earlier!
-- This will create the five bullets.

-- Now to show that it has done this already, and should move onto the next, we need to update the global times variable.

times = times + 1

-- This if and then statement is done.
-- We'll just have to end it in a different way before.

elseif times == 1 then

-- Instead of just putting "end", we put down else if.
-- if the previous requirements were failed, then else if checks these requirements to see if they match!
-- So if the previous requirements were met, then these requirements won't be checked and will be skipped.

-- It works, so I use it.

local newxpos = spawnerbulletxpos + Arena.width/4
local newypos = spawnerbulletypos

-- This different newxpos is so that the spawnerbullet spawns a quarter of the arena's width to the right.

spawnerbullet.SetVar('newxpos', newxpos)
spawnerbullet.SetVar('newypos', newypos)

createBullets()

times = times + 1

-- Same as usual.

elseif times == 2 then

-- Just changed it to times == 2 this time.

local newxpos = spawnerbulletxpos + -Arena.width/4
local newypos = spawnerbulletypos

-- Now the x position is a quarter to the left.

spawnerbullet.SetVar('newxpos', newxpos)
spawnerbullet.SetVar('newypos', newypos)

createBullets()

times = times + 1

elseif times == 3 then

-- Changed to times == 3

local newxpos = spawnerbulletxpos + Arena.width/2
local newypos = spawnerbulletypos

-- Now it will spawn a half of the arena's width to the right

spawnerbullet.SetVar('newypos', newypos)
spawnerbullet.SetVar('newxpos', newxpos)

createBullets()

times = times + 1

elseif times == 4 then

local newxpos = spawnerbulletxpos + -Arena.width/2
local newypos = spawnerbulletypos

-- Now it will spawn a half of the arena's width to the left

spawnerbullet.SetVar('newypos', newypos)
spawnerbullet.SetVar('newxpos', newxpos)

createBullets()
times = 0

-- Woah! What happened here?
-- Well, it will now loop back to the first if and then statement. Rinse and repeat.
-- That's it for the if and then statements!

end

-- make sure to end it

spawntimer = 0

-- reset the timer to 0

end

-- Now we're done with all the if and then statements.
-- Now we're going to make all of these bullets move!

-- You're probably wondering how we're going to keep track of every single bullet that spawns from the spawnerbullet.
-- Well here's your answer.

for i = 1, #bullets do

-- This pretty much says, "for every bullet in the bullets table, do this."
-- #bullets refers to a table called bullets
-- I think i = 1 refers to a single bullet at a time

-- So now we can make our bullets do what we want.
-- to make this a lot easier on us, we're going to shorten a thing. Specifically the name of the bullet.
-- Right now, it's called bullets[i]. We're going to change that to a local variable named bullet.

local bullet = bullets[i]

-- There we go. It has been shortened to the local bullet variable.

-- Now we need to make a new if and then statement.
-- First, we need to create a new variable.

local done = bullet.GetVar('done')

-- This calls upon a variable in which we haven't made yet. It will come up with a nil value.
-- Let's make an if and then statement now.

if done == nil then

-- Remember that global vel variable we made a while ago? Well we're going to call on it.

local yvel = vel

-- this creates our y velocity! 
-- How will we create our x velocity? That's going to take some math.
-- Here are a few long equations. I'll try to explain it to the best of my abilities.

local ydifference = Player.y - bullet.y

-- This calculates the difference between the y positions of the bullet (bullets[i]), and the Player.
-- NOTE - Player always has to have a capital P!!! Remember    Player.y
-- Now we're going to divide the ydifference by the yvel to get the number of frames it takes to reach the total ydifference

local frames = ydifference / yvel

-- And now we're going to get the xdifference.

-- First we need to find the difference between the original x position of the bulletspawner and this bullet
-- Remember putting the original x position of the spawnerbullet into these bullets? Well we just have to put that into a local variable.

local origxpos = bullet.GetVar('origxpos')

-- Then we'll calculate the difference

local difference = origxpos - bullet.x

-- Then we'll just tack this onto the Player's position in order to account for the difference between the spawnerbullet and this bullet.

local xdifference = (Player.x + difference) - bullet.x

-- We got that by subtracting the bullet's x position from the Player's x position.
-- Now we'll divide the xdifference with the frames variable to get the xvel

local xvel = xdifference / frames

-- And now we have our xvel!

--Let's put the xvel and yvel into this bullet.

bullet.SetVar('xvel', xvel)
bullet.SetVar('yvel', yvel)

-- And now let's update the done variable within the bullet variable.

bullet.SetVar('done', 1)

-- This will make the done variable change from a nil value to the number 1

end

-- Now we account for the fact that when it redoes this, it won't have the xvel and yvel on hand. It will need to reupdate them. That's why we have the done variable.

local xvel = bullet.GetVar('xvel')

local yvel = bullet.GetVar('yvel')

-- We update them get getting the xvel and yvel that we stored in the bullet variable, and put them into local xvel and yvel variable.

-- Let's make the new x and y positions for this bullet.

local bulletxpos = bullet.x + xvel

local bulletypos = bullet.y + yvel

-- And now, we can finally move the bullet.

bullet.MoveTo(bulletxpos, bulletypos)

-- We use the bullet.MoveTo( , ) command to move the bullet to the new bulletxpos and the new bulletypos.
-- and we're done.

end

-- end this for and do statement.

end

-- and end the function.

-- Congratulations! You just made your first Unitale wave!
-- Make sure to look over your code for any errors, and play test it.
-- Unitale has a built in debugger which will tell you if you have errors (which you probably do).
-- Please ask questions on /r/unitale.

-- Be sure to mess around with the variables and stuff to see what happens.
-- The best way to learn is to tinker with the stuff and to see if you can understand what's happening.
-- Have fun!
-- Be sure to send me, /u/batchloo1, your unitale waves so I can check out what you've made!
-- Who knows, you might teach me something new.
function OnHit(bullet)
    Player.hurt(30)
end