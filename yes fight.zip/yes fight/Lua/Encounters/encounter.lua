-- A basic encounter script skeleton you can copy and modify for your own creations.

music = "yes" --Either OGG or WAV. Extension is added automatically. Uncomment for custom music.
encountertext = "Aux..." --Modify as necessary. It will only be read out in the action select screen.
nextwaves = {"bullettest_chaserorb"}
wavetimer = 4.0
arenasize = {155, 130}

enemies = {
"poseur"
}

autolinebreak = true

enemypositions = {
{10, 0}
}
-- Player stuff
Player.lv = 15
Player.hp = 76
Player.atk = 95
Player.SetMaxHPShift(76, 0, true, false, false)
Player.def = 10
Player.name = "CHARA"
-- End player stuff



-- A custom list with attacks to choose from. Actual selection happens in EnemyDialogueEnding(). Put here in case you want to use it.
possible_attacks = {"bullettest_chaserorb", "bullettest_bouncy", "bullettest_touhou", "tutorialwave","ORANGE","COMBINED","finale","bullettest_blasters"}

function EncounterStarting()
    -- If you want to change the game state immediately, this is the place.
    Inventory.AddCustomItems({"Donut", "Donut", "Donut", "Donut", "Donut", "Donut","One Shot Blade"},{0,0,0,0,0,0,1})
    Inventory.SetInventory({"Donut", "Donut", "Donut", "Donut", "Donut", "Donut","One Shot Blade"})
    State("ENEMYDIALOGUE")
end
-- DIALOGUE
dialogue_counter = 0
dialogue = {"[voice:AuxViles][noskip] Hello... back again?", "[voice:AuxViles][noskip]I will assure you this time I won't [color:ff0000]lose.", "[novoice][noskip][color:ff0000]I WILL DISPOSE OF YOU!", "[voice:AuxViles] If you want to hurt the others...", "[voice:AuxViles]You must get through me...", "[voice:AuxViles]I really don't see how you like doing this...", "[voice:AuxViles]I would give up if I were you...","[voice:AuxViles]It would be good for you to die!", "[voice:AuxViles]You really should stop soon...", "[voice:AuxViles]I'm not joking you should stop...", "[voice:AuxViles]keep on going and i will use...", "[voice:AuxViles]My special attack!","[voice:AuxViles]Get ready...","[voice:AuxViles]Here goes nothing!", "..." }
function EnemyDialogueStarting()
    -- Good location for setting monster dialogue depending on how the battle is going.
        if dialogue_counter < #dialogue then
            dialogue_counter = dialogue_counter + 1
        end
        enemies[1].SetVar("currentdialogue",dialogue[dialogue_counter])
end

-- ATTACKS
attack_counter = 0
attack_list = {"ORANGE","bullettest_blasters","finale", "COMBINED", "tutorialwave","bullettest_chaserorb","bullettest_bouncy","bullettest_blasters","bullettest_chaserorb", "bullettest_blasters","ORANGE","finale","finale","bullettest_touhou"}
function EnemyDialogueEnding()
    -- Good location to fill the 'nextwaves' table with the attacks you want to have simultaneously.
    attack_counter = attack_counter + 1
    if attack_counter > #attack_list then
        attack_counter = 1
    end
    nextwaves = { attack_list[attack_counter] }
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    encountertext = RandomEncounterText("AA") --This built-in function gets a random encounter text from a random enemy.
end

function HandleSpare()
    State("yes")
end

function HandleItem(ItemID)
    if ItemID == "ONE SHOT BLADE" then
        Inventory.SetAmount(99999999)
        BattleDialog({"only for cheaters"})
    end
    if ItemID == "DONUT" then
        Player.Heal(30)
        BattleDialog({"You eat the donut... Delicous"})
    end
end
