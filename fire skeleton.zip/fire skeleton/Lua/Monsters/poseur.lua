-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"How is it floating like that.", "Smells like ashes.", "Its getting hot."}
commands = {"Joke", "Insult", "Compliment"}
randomdialogue = {"Nice and hot", "So warm...", "You are very cold"}

autolinebreak = true

sprite = "poseur" --Always PNG. Extension is added automatically.
name = "Fire skeleton"
hp = 100
atk = 5
def = 2
check = "A floating head thats on fire... wow."
dialogbubble = "right" -- See documentation for what bubbles you have available.
canspare = false
cancheck = true

-- Happens after the slash animation but before 
function HandleAttack(attackstatus)
    if attackstatus == -1 then
        -- player pressed fight but didn't press Z afterwards
    else
        -- player did actually attack
    end
end
 
-- This handles the commands; all-caps versions of the commands list you have above.
function HandleCustomCommand(command)
    if command == "JOKE" then
        currentdialogue = {"Haha."}
        canspare = true
        BattleDialog({"You tell a joke."})
    elseif command == "INSULT" then
        currentdialogue = {"grrr."}
        atk = atk + 3
        BattleDialog = ({"You insult it..."})
    elseif command == "COMPLIMENT" then
        currentdialogue = {"thank you"}
        atk = atk - 2
        BattleDialog = ({"You compliment it..."})
    end
    BattleDialog({"You selected " .. command .. "."})
end