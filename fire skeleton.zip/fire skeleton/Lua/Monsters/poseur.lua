-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"How is it floating like that.", "Smells like ashes.", "Its getting hot."}
commands = {"Joke", "Insult", "Compliment"}
randomdialogue = {"Nice and \nhot", "So warm...", "You are \ncold"}

autolinebreak = true

sprite = "poseur" --Always PNG. Extension is added automatically.
name = "Fire skeleton"
gold = 30
xp = 10
hp = 100
atk = 5
def = 2
check = "A floating head thats on fire... wow."
dialogbubble = "right" -- See documentation for what bubbles you have available.
canspare = false
cancheck = true

-- Happens after the slash animation but before 
function HandleAttack(attackstatus)
    if attackstatus == -1 then
        -- player pressed fight but didn't press Z afterwards
    else
        -- player did actually attack
    end
end
 
-- This handles the commands; all-caps versions of the commands list you have above.
function HandleCustomCommand(command)
    if command == "JOKE" then
        currentdialogue = {"Haha."}
        canspare = true
    elseif command == "INSULT" then
        currentdialogue = {"grrr."}
    elseif command == "COMPLIMENT" then
        currentdialogue = {"thank \nyou"}
    end
    BattleDialog({"You selected " .. command .. "."})
end